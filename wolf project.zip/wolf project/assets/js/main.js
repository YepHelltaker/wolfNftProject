let btn = document.querySelector('.menu-btn')

btn.addEventListener('click', function () {
  this.classList.toggle('is-active')
})
